# Known Issues / Developer Checklist

- `app/index.html` is very large and should eventually be split into smaller JS/CSS files.
- OAuth start code still has a client id hard-coded in the frontend; developer should move configuration to a safe/public config pattern.
- `deriv/callback/index.html` points to `/.netlify/functions/deriv-token-exchange`, but that function is not enabled in this handoff zip.
- The original package had a hard-coded account picker. It was removed from the active dashboard and archived in `archive/original/app.index.original.html`.
- Support functions use Telegram/Supabase env vars; those are optional and must be configured in Netlify if needed.
- Test on Netlify Preview before connecting any real account/session.
