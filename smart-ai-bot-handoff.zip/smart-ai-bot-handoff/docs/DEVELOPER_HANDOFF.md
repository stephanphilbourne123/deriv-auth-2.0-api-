# Developer Handoff Notes

## Goal

Finish the real backend/account connection for the Mickey Smart AI Bot while keeping secrets server-side and keeping the dashboard honest about connection status.

## Current state

The app is mostly a static frontend deployed on Netlify. The dashboard lives in `app/index.html`. It has strategy panels and UI state already built.

The project previously had Netlify Functions in the wrong folder:

```text
legacy-parts/netlify/functions/
```

This handoff package moved the support functions to the correct folder:

```text
netlify/functions/
```

The old Deriv token function was copied to:

```text
netlify/functions/_disabled/oauth-token.js.disabled
```

It is disabled on purpose so it does not accidentally go live without review.

## Important changes made in this handoff zip

1. Added `netlify.toml` with root publish and `netlify/functions` path.
2. Added `.env.example` for Netlify environment variables.
3. Moved support functions into `netlify/functions/`.
4. Archived original dashboard and callback files in `archive/original/`.
5. Removed the hard-coded fake account picker from `app/index.html`.
6. Changed the callback page to call `/.netlify/functions/deriv-token-exchange` as a backend placeholder.

## Backend work the next developer must finish

The next developer must create/review the real backend function named:

```text
netlify/functions/deriv-token-exchange
```

That backend should handle the account connection flow, return only the data the frontend needs, and never expose private tokens or secrets in frontend JavaScript.

Expected frontend callback route:

```text
/deriv/callback
```

Expected backend endpoint from the callback page:

```text
/.netlify/functions/deriv-token-exchange
```

## UI work the next developer should wire

The developer should replace local/fake connection state with real backend/session state:

- Dashboard should say `Connected` only after backend/session success.
- Balance should come from the real authenticated account response/session.
- Account list should come from backend response, not hard-coded rows.
- Demo/live switching should use real returned account/session type.
- If backend fails, dashboard should stay `Offline` or `Disconnected`.

## Files to review first

```text
app/index.html
  Search for: startDerivOAuth, connectWS, authorize, balance, proposal, buy

deriv/callback/index.html
  Callback route that now calls the Netlify function placeholder.

netlify/functions/_disabled/oauth-token.js.disabled
  Old disabled token-exchange reference. Review before using anything from it.

netlify.toml
  Netlify publish/function config.
```

## Do not commit secrets

Keep these out of the frontend and out of GitHub:

- access tokens
- refresh tokens
- OTP URLs
- private API keys
- service role keys
- real account identifiers unless intentionally displayed to the logged-in user
