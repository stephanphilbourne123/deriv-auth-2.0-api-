# Netlify Functions

This is the correct Netlify Functions folder.

Enabled support functions:

- `support-send.mjs`
- `support-poll.mjs`
- `telegram-webhook.mjs`

Disabled/reference material:

- `_disabled/oauth-token.js.disabled`

The live account/token/session function is intentionally not enabled in this handoff package. The next developer should implement/review it as `deriv-token-exchange` and keep secrets in Netlify environment variables.
