# TODO: deriv-token-exchange backend function

Create a reviewed Netlify Function with this deployed endpoint:

```text
/.netlify/functions/deriv-token-exchange
```

The callback page already posts these fields to that endpoint:

```json
{
  "code": "...",
  "code_verifier": "...",
  "redirect_uri": "https://your-site/deriv/callback"
}
```

The developer should use official provider documentation, keep all secrets server-side, validate state/session, and return only safe account/session data required by the dashboard.

Do not expose private tokens or OTP URLs in static HTML or public JavaScript.
